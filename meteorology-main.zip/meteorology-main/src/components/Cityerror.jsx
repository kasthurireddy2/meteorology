import React from "react";

import img1 from './assets/error.gif'
function Cityerror() {
  return (
    <div>
            <img src={img1} style={{marginTop:'-1px'}} height={350} width={300}/>
    </div>
  );
}

export default Cityerror;