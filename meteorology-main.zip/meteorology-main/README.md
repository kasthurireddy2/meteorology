# Meteorologistic⛅
### Use https://meteorologistic.netlify.app/ and Have an up to date information about the weather which will helps you to take well-read decisions:)
### Created With :
  React Js <br/>
  Weather API <br/>
  Canva <br/>
<hr>

## Screenshots 🎞 :
<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190917904-8dd9c767-71c3-4357-a2d2-4c0e69c105bd.png">
<br/><br/>

<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190918278-d2758596-2f71-4326-bff4-0e993f78a449.png">
<br/><br/>

<img width="960" alt="image" src="https://user-images.githubusercontent.com/92162945/190918447-9f433a50-1164-47ae-9249-925a2d7ab76c.png">
